
public interface ICargoCarrier {

    void carryCargo();

}
