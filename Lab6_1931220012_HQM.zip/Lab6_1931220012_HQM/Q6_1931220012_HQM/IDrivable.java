
public interface IDrivable {

    void drive();
}
