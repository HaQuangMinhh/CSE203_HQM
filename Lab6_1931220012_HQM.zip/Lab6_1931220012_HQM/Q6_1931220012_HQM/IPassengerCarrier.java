
public interface IPassengerCarrier {

    void carryPassenger();
}
