public interface INotificationService {

    void send ( String message ) ; 

}
