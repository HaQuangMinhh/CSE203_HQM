
public class PrintPlugin implements IPlugin {

    @Override
    public void excute() {
        System.out.println("Printing document......");
    }

}
