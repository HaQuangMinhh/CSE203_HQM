
public interface IPlugin {

    void excute();
}
