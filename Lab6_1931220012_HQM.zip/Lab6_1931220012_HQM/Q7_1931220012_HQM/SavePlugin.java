
public class SavePlugin implements IPlugin {

    @Override
    public void excute() {
        System.out.println("Saving Plugin......");
    }

}
