public interface IOrderValidation {

    boolean validate ( Order order ) ; 

}
