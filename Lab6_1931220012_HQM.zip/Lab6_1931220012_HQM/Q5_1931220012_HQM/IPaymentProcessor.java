public interface IPaymentProcessor {

    void processPayment (Order order) ; 
}
