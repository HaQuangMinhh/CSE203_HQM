public interface IOrderFulfillment {

    void fulfillOrder (Order order) ; 
}
