public interface IPayPalPayment {

    void pay (double money ) ; 
    void processRefund (double money) ; 


}
