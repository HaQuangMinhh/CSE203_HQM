public interface Shape {

    void draw();

    double calculateArea();

}
