
import java.util.*;

public class Question6 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

    }

}
