
public class Question1 {

    public static void main(String[] args) {

        RetailedItem retailedItem1 = new RetailedItem("Jacket", 12, 59.95);
        RetailedItem retailedItem2 = new RetailedItem("Designer Jeans", 40, 34.95);
        RetailedItem retailedItem3 = new RetailedItem("Shirt", 20, 24.95);

        System.out.println(retailedItem1);
        System.out.println(retailedItem2);
        System.out.println(retailedItem3);

    }

}
