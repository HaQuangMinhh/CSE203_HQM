
public class SimpleCoffee implements Coffee {

    @Override
    public double getCost() {
        return 3.5;
    }

    @Override
    public String getDescription() {
        return "Simple Coffee";

    }

}
