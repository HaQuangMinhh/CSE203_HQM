
public class Rectangle implements Shape {

    private double Width;
    private double Length;

    @Override
    public void draw() {
        System.out.println("Drawing a rectangle");
    }

}
