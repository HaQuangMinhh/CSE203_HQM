
public class Circle implements Shape {

    private double Diameter;

    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }

}
