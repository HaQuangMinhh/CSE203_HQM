
public class Square implements Shape {

    private double Side;

    @Override
    public void draw() {
        System.out.println("Drawing a square");
    }

}
