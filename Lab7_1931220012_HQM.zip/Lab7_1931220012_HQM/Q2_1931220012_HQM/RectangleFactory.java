
public class RectangleFactory extends ShapeFactory {

    @Override
    Shape getShape() {
        return new Rectangle();
    }

}
