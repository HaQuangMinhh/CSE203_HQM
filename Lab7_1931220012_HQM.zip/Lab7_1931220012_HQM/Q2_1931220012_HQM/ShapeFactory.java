
abstract class ShapeFactory {

    abstract Shape getShape();

}
