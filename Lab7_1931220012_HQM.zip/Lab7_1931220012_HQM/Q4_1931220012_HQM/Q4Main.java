
public class Q4Main {

    public static void main(String[] args) {

        // Strategy Pattern : change thuật toán + hành vi 
    
    }

}
