
import java.util.List;

public class ShoppingCart {

    private List<ShoppingItem> items;
    private PaymentStrategy paymentStrategy;

}
